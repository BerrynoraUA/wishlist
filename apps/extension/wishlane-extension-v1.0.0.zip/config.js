/**
 * Wishlane Extension – Supabase configuration.
 *
 * These values are the same NEXT_PUBLIC_* env vars used by the frontend.
 * They are public (anon) keys and safe to ship in the extension.
 *
 * ⚠️  Fill in the values below before building / loading the extension.
 */
const WISHLY_CONFIG = {
  SUPABASE_URL: "https://iwdgsvydfgtuqdoowbhj.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_jvMJ1MbHj2SMxxwY36yRYg_Lsjok7Fq",
  SITE_URL: "https://wishlane.net",
};
